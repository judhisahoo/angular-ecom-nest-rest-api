// src/app/app.spec.ts
describe('Simple Test', () => {
  it('should pass', () => {
    expect(2 + 2).toBe(4);
  });
});
