// jest.config.ts
import type { Config } from 'jest';

const config: Config = {
  preset: 'jest-preset-angular',

  // REMOVED `globalSetup` as per the warning message
  // and because it is not needed for a basic setup.

  // This transform property is what fixes the 'Unexpected token <' error
  // by telling Jest to process both TS and HTML files with the Angular preset.
  transform: {
    '^.+\\.(ts|mjs|js|html)$': 'jest-preset-angular',
  },

  // This is crucial for correctly ignoring node_modules
  transformIgnorePatterns: ['node_modules/(?!.*\\.mjs$)'],

  // This maps CSS imports to a mock, so Jest doesn't try to parse them
  moduleNameMapper: {
    '^.+\\.(css|less|scss)$': 'identity-obj-proxy',
  },
};

export default config;
