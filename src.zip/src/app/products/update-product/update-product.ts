import { Component } from '@angular/core';

@Component({
  selector: 'app-update-product',
  imports: [],
  templateUrl: './update-product.html',
  styleUrl: './update-product.css',
})
export class UpdateProductComponent {}
