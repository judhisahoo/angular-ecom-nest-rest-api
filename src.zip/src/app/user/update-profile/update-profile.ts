import { Component } from '@angular/core';

@Component({
  selector: 'app-update-profile',
  imports: [],
  templateUrl: './update-profile.html',
  styleUrl: './update-profile.css',
})
export class UpdateProfileComponent {}
