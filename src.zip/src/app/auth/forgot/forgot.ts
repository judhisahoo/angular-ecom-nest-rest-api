import { Component } from '@angular/core';

@Component({
  selector: 'app-forgot',
  imports: [],
  templateUrl: './forgot.html',
  styleUrl: './forgot.css',
})
export class ForgotComponent {}
