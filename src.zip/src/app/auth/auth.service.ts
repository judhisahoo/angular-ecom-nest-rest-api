import { Injectable } from '@angular/core';
import { api } from '../../lib/api/api';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor() {}

  async login(email: string, password: string): Promise<any> {
    try {
      const response = await api.auth.login({ email, password });
      return response.data;
    } catch (error: any) {
      throw new Error('Login failed. Please check your credentials.');
    }
  }
}
